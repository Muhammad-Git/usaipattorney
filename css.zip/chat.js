







// var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
// (function(){
// var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
// s1.async=true;
// s1.src='https://embed.tawk.to/65b165d80ff6374032c483ab/1hkufbllm';
// s1.charset='UTF-8';
// s1.setAttribute('crossorigin','*');
// s0.parentNode.insertBefore(s1,s0);
// })();


var dtm = window.parent.document.createElement('script'); dtm.type="text/javascript"; dtm.id = 'ze-snippet'; dtm.src='https://static.zdassets.com/ekr/snippet.js?key=7b51fae7-0a62-42ea-abf8-59f7f76de0b3'; var d = window.parent.document.getElementsByTagName('head')[0]; d.appendChild(dtm); var dtmf = window.parent.document.createElement('script'); dtmf.type="text/javascript"; dtmf.id = '_adobe_dtm_script_footer_tag'; dtmf.text='_satellite.pageBottom();'; var bd = window.parent.document.getElementsByTagName('body')[0]; bd.appendChild(dtmf);


// settimeout(function(){

  
// window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
// d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
// _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
// $.src="https://v2.zopim.com/?6dG0dVpfaIq7RTMzdFw6MGYqBfp1hE64";z.t=+new Date;$.
// type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");

// var dtm = window.parent.document.createElement('script'); dtm.type="text/javascript"; dtm.id = 'ze-snippet'; dtm.src='https://static.zdassets.com/ekr/snippet.js?key=9cd774ce-bd63-45d2-ae58-09d5e8360f8e'; var d = window.parent.document.getElementsByTagName('head')[0]; d.appendChild(dtm); var dtmf = window.parent.document.createElement('script'); dtmf.type="text/javascript"; dtmf.id = '_adobe_dtm_script_footer_tag'; dtmf.text='_satellite.pageBottom();'; var bd = window.parent.document.getElementsByTagName('body')[0]; bd.appendChild(dtmf);

// },5000)


 // var el = document.querySelectorAll(".chat");              
 //  for(var i =0; i < el.length; i++) {
 //      (function(i) {
 //            el[i].onclick = function() {   

 //            	$zopim.livechat.window.show();
             
 //             };   
 //       })(i);
 //   }



// var dtm = window.parent.document.createElement('script'); dtm.type="text/javascript"; dtm.id = 'ze-snippet'; dtm.src='https://static.zdassets.com/ekr/snippet.js?key=7b51fae7-0a62-42ea-abf8-59f7f76de0b3'; var d = window.parent.document.getElementsByTagName('head')[0]; d.appendChild(dtm); var dtmf = window.parent.document.createElement('script'); dtmf.type="text/javascript"; dtmf.id = '_adobe_dtm_script_footer_tag'; dtmf.text='_satellite.pageBottom();'; var bd = window.parent.document.getElementsByTagName('body')[0]; bd.appendChild(dtmf);


window.$zopim||function(a,d){
var b=$zopim=function(a){b._.push(a)},c=b.s=a.createElement(d);
a=a.getElementsByTagName(d)[0];
b.set=function(a){b.set._.push(a)};b._=[];b.set._=[];c.async=!0;c.setAttribute("charset","utf-8");c.src="";b.t=+new Date;c.type="text/javascript";a.parentNode.insertBefore(c,a)}
(document,"script");

$zopim(function(){function a(a){1<=a&&$zopim.livechat.window.show()}$zopim.livechat.setOnUnreadMsgs(a)});




    function setButtonURL() {
        $zopim.livechat.window.show();
        
    }
    function toggleChat() {
        $zopim.livechat.window.show();
        
    }

  

$(".chats, .chat").click(function(){
  $zopim.livechat.window.show();
  
});




        function setButtonURL() {
            $zopim.livechat.window.show();
              // Tawk_API.toggle();
         }
        function toggleChat() {
            $zopim.livechat.window.show();
              // Tawk_API.toggle();
         }

window.onload = function(){
            setTimeout(function(){
            setButtonURL();
            // Tawk_API.toggle();
             $zopim.livechat.window.show();
            }, 3000);
            };



            
// window.$zopim||function(a,d){
// var b=$zopim=function(a){b._.push(a)},c=b.s=a.createElement(d);a=a.getElementsByTagName(d)[0];b.set=function(a){b.set._.push(a)};b._=[];b.set._=[];c.async=!0;c.setAttribute("charset","utf-8");c.src="";b.t=+new Date;c.type="text/javascript";a.parentNode.insertBefore(c,a)}
// (document,"script");

// $zopim(function(){function a(a){1<=a&&$zopim.livechat.window.show()}$zopim.livechat.setOnUnreadMsgs(a)});